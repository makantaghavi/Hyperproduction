/* Duplicate functionality of Merge and Interleave 
var Type = require("../model/ports").Type;
var RunningState = require("../model/MapNode").RunningState;
module.exports.StreamMerger = {
  nodetype: "StreamMerger",
  path: __filename,
  inputs: {
  },
  outputs: {
    out: {type: Type.OBJECT, defaultValue: {}},
  },
  procfn:function (ports, state, id, triggerPort) {
    if (triggerPort.name != "out") {
        console.log(triggerPort.name);
        ports.out.set(triggerPort.get());
    }
  },
};
*/

module.exports.StreamMerger = require("../nodes/BaseModules").Merge;