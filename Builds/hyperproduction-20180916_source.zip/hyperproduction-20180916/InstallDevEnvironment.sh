#!/bin/bash
npm install 
npm run-script setup
