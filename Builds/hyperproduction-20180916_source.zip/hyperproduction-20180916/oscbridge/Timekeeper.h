//
//  Timekeeper.h
//  vocal-augmentation
//
//  Created by Kevin King on 4/22/15.
//
//

#ifndef __vocal_augmentation__Timekeeper__
#define __vocal_augmentation__Timekeeper__

#include <stdio.h>
#include <iostream>
#include <deque>
#include <chrono>
#include <functional>
#include <mutex>
#include <thread>

#include <cmath>

const double BPM_TO_BPMICROS = 1./(60. * 1e6);

using namespace std;
using namespace std::chrono;

typedef time_point<steady_clock> tick_t;


class Event {
public:
    double beat;
    function<void(void)> cb;
};

// reverse order
inline bool operator< (const Event& lhs, const Event& rhs){
    return !(lhs.beat < rhs.beat);
}

// 120 bpm in micros
const long kMicrosPerMinute = 1000000 * 60;

enum QuantizeMode {
    QUANTIZE_UP,
    QUANTIZE_DOWN,
    QUANTIZE_BOTH,
};
inline double quantize(double x, double bucket, QuantizeMode qMode = QUANTIZE_BOTH) {
        // quantize
    double rem = remainder(x, bucket);
    switch(qMode) {
        case QUANTIZE_UP:
            return x + (bucket - rem);
        case QUANTIZE_DOWN:
            return x - rem;
        case QUANTIZE_BOTH:
            if (rem > bucket / 2) {
                // quantize up
                return x + (bucket - rem);
            } else {
                // quantize down
                return x - rem;
            }
    }
    return x;
}

class Timekeeper {
public:
    Timekeeper() {
        _lastTick = steady_clock::now();
        _paused = true;
        _tickResolution = microseconds(500);
    }

    void start() {
        _tickThread = thread(bind(&Timekeeper::_loop, this));
    }

    void tick() {
        lock.lock();
        tick_t n = steady_clock::now();
        if (!_paused) {
            long ticksPassed = duration_cast<microseconds>(n - _lastTick).count();
            _beat += _bpm * ticksPassed / kMicrosPerMinute;
        }
        _lastTick = n;
        while (!_events.empty() && _events.front().beat <= _beat) {
            _events.front().cb();
            pop_heap(_events.begin(), _events.end());
            _events.pop_back();
        }
        lock.unlock();
    }

    void togglePaused() {
        lock.lock();
        _paused = !_paused;
        lock.unlock();
    }

    bool getPaused() {
        return _paused;
    }

    void setBPM(double bpm) {
        lock.lock();
        _bpm = bpm;
        lock.unlock();
    }

    double getBPM() {
        return _bpm;
    }

    void addEvent(Event& e) {
        lock.lock();
        _events.push_back(e);
        push_heap(_events.begin(), _events.end());
        lock.unlock();
    }

    void addFuncAt(function<void(void)> f, double beat) {
        Event e;
        e.cb = f;
        e.beat = beat;
        addEvent(e);
    }

    void addFuncInMicros(function<void(void)> f, size_t microsDelta) {
        lock_guard<decltype(lock)> _lock(lock);
        Event e;
        e.cb = f;
        e.beat = _beat + (double) (_bpm * BPM_TO_BPMICROS * microsDelta);
        addEvent(e);
    };

    void addFuncIn(function<void(void)> f, double beatDelta, double quantizeRatio = 0) {
        lock.lock();
        Event e;
        e.cb = f;
        e.beat = _beat + beatDelta;
        if (quantizeRatio > 0) {
            // quantize
            double rem = remainder(e.beat, quantizeRatio);
            if (rem > quantizeRatio / 2) {
                // quantize up
                e.beat += (quantizeRatio - rem);
            } else {
                // quantize down
                e.beat -= rem;
            }
        }
        addEvent(e);
        lock.unlock();
    }

    double getBeat() {
        return _beat;
    }


private:
    deque<Event> _events;
    tick_t _lastTick;
    double _bpm;
    double _beat;
    bool _paused;
    recursive_mutex lock;
    microseconds _tickResolution;
    thread _tickThread;

    void _loop() {
        while (1) {
            tick();
            this_thread::sleep_for(microseconds(_tickResolution));
        }
    }
};

#endif /* defined(__vocal_augmentation__Timekeeper__) */
