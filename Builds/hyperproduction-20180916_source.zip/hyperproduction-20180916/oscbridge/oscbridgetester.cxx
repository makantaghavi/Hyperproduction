/*
    Simple example of sending an OSC message using oscpack.
*/

#include "oscpack/osc/OscOutboundPacketStream.h"
#include "oscpack/ip/UdpSocket.h"

#include <ctime>
#include <iostream>
#include <sstream>

#include <unistd.h>

using namespace std;

#define ADDRESS "127.0.0.1"
#define PORT 4663

#define OUTPUT_BUFFER_SIZE 1024

void testSmpte() {
    UdpTransmitSocket transmitSocket( IpEndpointName( ADDRESS, PORT ) );

    char buffer[OUTPUT_BUFFER_SIZE];
    auto start = std::chrono::high_resolution_clock::now();
    while (true) {
        auto elapsed = std::chrono::high_resolution_clock::now() - start;
        long long microseconds = std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count();
        int h, m, s, f;
        h = microseconds/1000000 / 60 / 60;
        m = microseconds/(1000000 * 60) % 60;
        s = microseconds/(1000000) % 60;
        f = microseconds*25/(1000000) % 25;
        stringstream ss;
        char* timeStr = new char[12];
        sprintf(timeStr, "%02i:%02i:%02i:%02i", h, m, s, f);
        osc::OutboundPacketStream p( buffer, OUTPUT_BUFFER_SIZE );
        p << osc::BeginBundleImmediate
            << osc::BeginMessage( "/fensadense/mtc" )
            << timeStr<< osc::EndMessage
            << osc::EndBundle;

        transmitSocket.Send( p.Data(), p.Size() );
        usleep(40000);
    }

};

void testTrig() {
    UdpTransmitSocket transmitSocket( IpEndpointName( ADDRESS, PORT ) );

    char buffer[OUTPUT_BUFFER_SIZE];
    int32_t i = 0;
    while (true) {
        cout << "Sending Note Trigger UDP message\n";
        int32_t chan = i, note = i, vel = i, dur = (int32_t) (1e6 * .5);
        stringstream ss;
        osc::OutboundPacketStream p( buffer, OUTPUT_BUFFER_SIZE );
        p << osc::BeginBundleImmediate
            << osc::BeginMessage( "/fensadense/midi/note/trig" )
            << chan << note << vel << dur << osc::EndMessage
            << osc::EndBundle;

        transmitSocket.Send( p.Data(), p.Size() );
        usleep(1e6 * 1.5);
        i = (i + 1) % 16;
    }
};

int main(int argc, char* argv[])
{
    (void) argc; // suppress unused parameter warnings
    (void) argv; // suppress unused parameter warnings

    testTrig();
}

