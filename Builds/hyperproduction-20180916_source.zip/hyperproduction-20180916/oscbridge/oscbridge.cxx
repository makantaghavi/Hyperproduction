#include <iostream>

#include "oscpack/osc/OscReceivedElements.h"
#include "oscpack/osc/OscPacketListener.h"
#include "oscpack/ip/UdpSocket.h"
#include <sstream>
#include <string>
#include <iostream>
#include <thread>

#include <RtMidi.h>

#ifdef WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif // win32

#include "Timekeeper.h"

using namespace std;

//Cross platform sleep
void sleepcp(int milliseconds);
void sleepcp(int milliseconds) // cross-platform sleep function
{
    #ifdef WIN32
    Sleep(milliseconds);
    #else
    usleep(milliseconds * 1000);
    #endif // win32
}

class ExamplePacketListener : public osc::OscPacketListener {
public:
    ExamplePacketListener(string outputMidiDevice) : outputMidiDevice(outputMidiDevice) {
        midiOut = new RtMidiOut();
        midiOut->openVirtualPort(outputMidiDevice);
        _timekeeper = new Timekeeper();
        _timekeeper->setBPM(120.);
        _timekeeper->start();
        _timekeeper->togglePaused();
    }
    virtual ~ExamplePacketListener(){
        delete midiOut;
    };
protected:

    virtual void ProcessMessage( const osc::ReceivedMessage& m,
                                const IpEndpointName& remoteEndpoint )
    {
        try{
            // example of parsing single messages. osc::OsckPacketListener
            // handles the bundle traversal.

            if( strcmp( m.AddressPattern(), "/fensadense/mtc" ) == 0 ){
                osc::ReceivedMessageArgumentStream args = m.ArgumentStream();
                const char* smpteCStr;
                char h, m, s, ff;
                args >> smpteCStr >> osc::EndMessage;

                std::cout << "received '/fensadense/mtc' message with arguments: "
                    << smpteCStr << "\n";
                const string& smpteStr(smpteCStr);
                h = (smpteStr[0]-'0')*10 + smpteStr[1] - '0';
                m = (smpteStr[3]-'0')*10 + smpteStr[4] - '0';
                s = (smpteStr[6]-'0')*10 + smpteStr[7] - '0';
                ff = (smpteStr[9]-'0')*10 + smpteStr[10] - '0';
                cout << (int)h << ':' << (int)m << ':' << (int)s << '.' << (int)ff << endl;
                 //add framerate to hours byte
                h |= 1 << 5;
                uint8_t byte_mask = 0xF;
                unsigned char msgBytes[8][2] =
                 {
                    {0xF1, (uint8_t) (ff & byte_mask)},
                    {0xF1, (uint8_t) ((0x10) | (ff >> 4))},
                    {0xF1, (uint8_t) ((0x20) | (s & byte_mask)) },
                    {0xF1, (uint8_t) ((0x30) | (s >> 4)) },
                    {0xF1, (uint8_t) ((0x40) | (m & byte_mask)) },
                    {0xF1, (uint8_t) ((0x50) | (m >> 4)) },
                    {0xF1, (uint8_t) ((0x60) | (h & byte_mask)) },
                    {0xF1, (uint8_t) ((0x70) | (h >> 4)) },
                };
                vector<vector<unsigned char> > msgs(8);
                for (int i = 0; i < 8; ++i) {
                    vector<unsigned char> msg;
                    msg.push_back(msgBytes[i][0]);
                    msg.push_back(msgBytes[i][1]);
                    msgs.push_back(msg);
                }
                for (int i = 0; i < msgs.size(); ++i) {
                    midiOut->sendMessage(&msgs[i]);
                }


            } else if ( strcmp( m.AddressPattern(), "/fensadense/midi/note/on") == 0 ) {

              osc::ReceivedMessageArgumentStream args = m.ArgumentStream();
              osc::int32 chan, note, vel;
              args >> chan >> note >> vel >> osc::EndMessage;
              std::cout << "received '/fensadense/midi/note/on' message with arguments: "
                    << chan << " " << note << " " << vel << "\n";


        	  // Note On: 144, 64, 90
     	      vector<unsigned char> nOnMsg;

     	      if (chan > 15 || chan < 0) {
     	      	std::cout << "Got out of range midi channel.\n";
     	      	return;
     	      }

     	      if (note > 127 || note < 0) {
     	      	std::cout << "Got out of range midi note.\n";
     	      	return;
     	      }

     	      if (vel > 127 || vel < 0) {
     	      	std::cout << "Got out of range midi vel.\n";
     	      	return;
     	      }


			  nOnMsg.push_back(144+chan);
			  nOnMsg.push_back(note);
			  nOnMsg.push_back(vel);
			  midiOut->sendMessage( &nOnMsg );
            }

            else if ( strcmp( m.AddressPattern(), "/fensadense/midi/note/off") == 0 ) {

              osc::ReceivedMessageArgumentStream args = m.ArgumentStream();
              osc::int32 chan, note, vel;
              args >> chan >> note >> vel >> osc::EndMessage;
              std::cout << "received '/fensadense/midi/note/off' message with arguments: "
                    << chan << " " << note << " " << vel << "\n";


        	  // Note On: 144, 64, 90
     	      vector<unsigned char> nOnMsg;

     	      if (chan > 15 || chan < 0) {
     	      	std::cout << "Got out of range midi channel.\n";
     	      	return;
     	      }

     	      if (note > 127 || note < 0) {
     	      	std::cout << "Got out of range midi note.\n";
     	      	return;
     	      }

     	      if (vel > 127 || vel < 0) {
     	      	std::cout << "Got out of range midi vel.\n";
     	      	return;
     	      }


			  nOnMsg.push_back(128+chan);
			  nOnMsg.push_back(note);
			  nOnMsg.push_back(vel);
			  midiOut->sendMessage( &nOnMsg );

            } else if ( strcmp( m.AddressPattern(), "/fensadense/midi/note/trig") == 0 ) {

              osc::ReceivedMessageArgumentStream args = m.ArgumentStream();
              // duration in mircos
              osc::int32 chan, note, vel, dur;
              args >> chan >> note >> vel >> dur >> osc::EndMessage;
              std::cout << "received '/fensadense/midi/note/trig' message with arguments: "
                    << chan << " " << note << " " << vel << " " << dur << "\n";


        	  // Note On: 144, 64, 90
     	      vector<unsigned char> nOnMsg;

     	      if (chan > 15 || chan < 0) {
     	      	std::cout << "Got out of range midi channel.\n";
     	      	return;
     	      }

     	      if (note > 127 || note < 0) {
     	      	std::cout << "Got out of range midi note.\n";
     	      	return;
     	      }

     	      if (vel > 127 || vel < 0) {
     	      	std::cout << "Got out of range midi vel.\n";
     	      	return;
     	      }

              cout << "NOTE ON " << chan << " " << note << " " << vel << endl;

              nOnMsg.push_back(144+chan);
              nOnMsg.push_back(note);
              nOnMsg.push_back(vel);
              midiOut->sendMessage( &nOnMsg );

              _timekeeper->addFuncInMicros([chan, note, this] {
                  // Note On: 144, 64, 90
                  vector<unsigned char> nOffMsg;
                  cout << "NOTE OFF " << chan << " " << note << endl;

                  nOffMsg.push_back(128+chan);
                  nOffMsg.push_back(note);
                  midiOut->sendMessage( &nOffMsg );
              }, dur);
            }
        }catch( osc::Exception& e ){
            // any parsing errors such as unexpected argument types, or
            // missing arguments get thrown as exceptions.
            std::cout << "error while parsing message: "
                << m.AddressPattern() << ": " << e.what() << "\n";
        }
    }

private:
    string outputMidiDevice;
    RtMidiOut* midiOut;
    Timekeeper* _timekeeper;
};




int main(int argc, char* argv[])
{
    int port = 8000;

    stringstream ss;
    if (argc > 1) {
        ss << argv[1];
        ss >> port;
    }

    string outputMidiDevice = "FensadenseMTC";
    if (argc > 2) {
        ss << argv[2];
        ss >> outputMidiDevice;
    }
    ExamplePacketListener listener(outputMidiDevice);
    UdpListeningReceiveSocket s(
            IpEndpointName( IpEndpointName::ANY_ADDRESS, port ),
            &listener );

    std::cout << "version 0.4\n";
    std::cout << "press ctrl-c to end\n";

    s.RunUntilSigInt();

    return 0;
}